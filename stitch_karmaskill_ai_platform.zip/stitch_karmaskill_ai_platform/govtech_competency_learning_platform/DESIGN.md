---
name: GovTech Competency & Learning Platform
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  stat-kpi:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.02em
  quote-italic:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system delivers an enterprise-grade, accessible, and dignified digital experience tailored for public servants and Indian Government employees. It strikes a deliberate balance between sovereign reliability, institutional clarity, and modern SaaS agility.

The visual style is **Corporate / Modern** anchored in clarity and utility:
- **Tone:** Civic-minded, motivational, structured, and profoundly legible.
- **Foundational Atmosphere:** Clean chalk-white content cards elevated above an airy, cool grey-blue canvas (`#F4F7FB`), avoiding institutional fatigue while preserving public sector gravitas.
- **National Touchpoints:** Dignified, subtle Indian tricolor accents (deep saffron `#FF9933`, white, India green `#138808`, and Ashoka blue) deployed with restraint on national branding badges and footer mottos ("A Smarter, Skilled India" & iGOT Karmayogi citations).
- **Competency-Driven Color Code:** Visual progress is semantic and instant, empowering officers with clear real-time gap evaluations, skill proficiencies, and assessment roadmaps.

## Colors

The system uses a calibrated palette constructed for accessibility (WCAG 2.1 AA/AAA compliance across text and data metrics), high readability under varied office and mobile conditions, and semantic competency evaluation.

### Core Canvas & Neutrals
- **App Canvas / Page Background:** `#F4F7FB` (cool slate-tinted canvas offering resting contrast against crisp cards)
- **Surface (Primary Cards & Panels):** `#FFFFFF`
- **Surface Muted / Inputs:** `#F8FAFC`
- **Border Crisp:** `#E2E8F0` (structural 1px boundaries)
- **Border Active / Focused:** `#93C5FD`
- **Text Headings / Slate Dark:** `#0F172A`
- **Text Body / Neutral Regular:** `#334155`
- **Text Muted / Subtitle:** `#64748B`
- **Text Disabled:** `#94A3B8`

### Brand & Interactive Accents
- **Primary Royal Blue:** `#2563EB` (Primary interactions, CTA buttons, active radio options, key KPI highlights)
- **Primary Deep (Hover):** `#1D4ED8`
- **Primary Light Tint:** `#EFF6FF` (selection fills, active navigation states, timer badges)

### Competency & Data Visualization Semantics
- **Excellence / Strong (100%):** `#10B981` (Vibrant Emerald) | Subtle Background: `#ECFDF5`
- **Proficient / Good:** `#3B82F6` (Sky / Bright Blue) | Subtle Background: `#EFF6FF`
- **Competent / Advanced Track:** `#8B5CF6` (Royal Violet) | Subtle Background: `#F5F3FF`
- **Moderate Gap / Alert:** `#F59E0B` (Warm Amber) | Subtle Background: `#FFFBEB`
- **Critical Gap / Action Needed:** `#EF4444` (Coral Red) | Subtle Background: `#FEF2F2`

## Typography

Typography uses `Inter` across all functional roles to provide systematic, crisp readability across multi-tier administrative dashboards, metric tables, and interactive assessment modules.

- **Display & Headlines:** Heavy weights (`700` and `800`) with tightened letter-spacing (`-0.01em` to `-0.02em`) convey executive authority and clear scanpaths for government officers.
- **Body:** Neutral `400` weights balanced at `14px` and `16px` provide long-form comfort for assessment prompts and policy learning items.
- **Labels & Microcopy:** High-contrast, tabular-friendly `600` weight labels ensure instant readability for pill badges, metric progress markers, and assessment status labels.

## Layout & Spacing

The layout is built on a 12-column adaptive fluid grid with a fixed persistent desktop sidebar (width `260px`) and an edge-to-edge mobile app layout with fixed bottom navigation.

### Breakpoints & Adaptive Logic
- **Desktop (1024px and above):** 
  - Persistent left navigation sidebar (`260px`).
  - Top administrative navigation bar with search and profile summary.
  - Multi-column dashboard grid (KPI strip in 4-column cards; core competency data in 2-column stacked modules).
  - Main view gutters set at `1.5rem` (`24px`) with safe outer margins of `2rem` (`32px`).
- **Tablet (768px – 1023px):**
  - Collapsible slim sidebar with icon triggers.
  - 2-column metric card flow; single-column detailed assessment matrices.
- **Mobile (< 768px):**
  - Desktop sidebar transforms into a fixed elevated 5-tab bottom navigation bar (`64px` height).
  - Top header simplifies to logo mark, condensed search, alert icon, and user badge avatar.
  - KPI summary strips collapse into a 2x2 grid or swipeable horizontal ribbon.
  - Outer margins reduce to `1rem` (`16px`) with inner card padding at `1rem`.

## Elevation & Depth

Visual hierarchy uses a crisp card-on-canvas system with subtle, ambient shadow diffusion and 1px borders.

### Elevation Levels
- **Canvas Base (Level 0):** Background tone `#F4F7FB`. Completely flat, non-elevated.
- **Card / Surface (Level 1):** `#FFFFFF` fill with a crisp `1px solid #E2E8F0` border and an ambient shadow: `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Card Hover / Interactive (Level 2):** Subtle lift with `box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.06), 0 4px 6px -4px rgba(15, 23, 42, 0.04)` and border transitioning to `#CBD5E1`.
- **Active / Focused Assessment Choice:** Tinted border `1.5px solid #2563EB` with surface fill `#F8FAFC` or `#EFF6FF` without heavy drop shadow.
- **Modal / Floating Bottom Nav (Level 3):** `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` with a clean top border `#E2E8F0`.

## Shapes

The design uses a **Rounded (Level 2)** shape language, balancing software cleanliness with an approachable, contemporary feel:

- **Primary Cards & Panels:** `1rem` (`16px`, or Tailwind `rounded-2xl`) radius, creating soft, welcoming modules that avoid rigid corporate sharpness.
- **Buttons & Input Fields:** `0.5rem` (`8px`) for compact touch targets, inputs, and action buttons.
- **Badges, Status Tags & Pills:** Full pill radius (`9999px` / `rounded-full`) for category tags, question types, proficiency percentages, and indicator counts.
- **Question Number Navigators:** `0.5rem` (`8px`) rounded squares (`36px x 36px`).
- **Progress Bars:** Fully pill-rounded track and fill (`rounded-full`) with `8px` height for smooth visual completion.

## Components

### 1. Buttons
- **Primary Action Button:** Royal blue `#2563EB` solid fill, `#FFFFFF` text, `0.5rem` corner radius, `10px 20px` padding, font weight `600`. Hover state: `#1D4ED8`. Active state: scale down `0.98`. Optional right arrow icon.
- **Secondary / Outline Button:** `#FFFFFF` fill with `1px solid #CBD5E1` border, `#334155` text. Hover state: `#F8FAFC` fill, `#2563EB` border.
- **Mini Action Buttons ("Start"):** Compact `6px 14px` pill or `6px` radius button using `#EFF6FF` background with `#2563EB` text; switches to solid blue on active engagement.

### 2. Cards & Stat Widgets
- **KPI Summary Cards:** Clean white `#FFFFFF` surface with light tinted icon bubbles (e.g. purple, blue, green, amber circles of `44px x 44px` containing SVG glyphs). Features large stat KPI typography (`28px`), small muted descriptive title, and a percentage comparison pill tag.
- **Competency Progression Cards:** Displays skill name, horizontal progress bar (`h-2.5`, `rounded-full`) with semantic color matching the competence bracket, followed by right-aligned bold percentage.
- **Question & Assessment Card:** Spacious card with `24px` padding, top breadcrumb or category pill ("Multiple Choice"), headline question prompt, and stacked answer option rows.

### 3. Multiple Choice & Quiz Selectors
- **Default State:** White background, `1px solid #E2E8F0` border, `14px 18px` padding, `12px` rounded radius, flex alignment with radio circle.
- **Selected / Active State:** `#EFF6FF` surface fill, `1.5px solid #2563EB` border, royal blue radio dot center.
- **Option Radio Dot:** `20px x 20px` circular container, `2px` neutral ring, interior filled dot when active.

### 4. Chips, Tags & Stat Badges
- **Question Type Pill:** `#F1F5F9` background, `#475569` text, `4px 10px` padding, `rounded-full`, uppercase tracking.
- **Competency Status Badge:** Light semantic tint background (`#ECFDF5`, `#EFF6FF`, `#FFFBEB`, `#FEF2F2`) with dark matching text (`#065F46`, `#1E40AF`, `#92400E`, `#991B1B`), weight `600`, font size `11px`.

### 5. Assessment Navigator Grid
- Compact 5-column square cell grid (`36px x 36px` to `40px x 40px` each, `rounded-lg`).
- **Answered:** Soft green background `#D1FAE5` with `#065F46` border/text.
- **Current Active:** `#EFF6FF` background with `#2563EB` border (2px) and text.
- **Unanswered / Upcoming:** `#F8FAFC` background with subtle `#E2E8F0` border and `#64748B` text.

### 6. Inputs & Search Fields
- Rounded `8px` or `20px` search capsule, `#F8FAFC` background, `1px solid #E2E8F0`, interior left search magnifying icon `#94A3B8`, placeholder font size `13px`. Focused state: `#FFFFFF` fill with `#2563EB` subtle halo outline.

### 7. Bottom Navigation (Mobile)
- Fixed bottom dock (`64px` height), `#FFFFFF` surface, `1px solid #E2E8F0` top edge.
- 5 icon + label items (Dashboard, Assessments, Learning, Progress, Recommendations). Active item highlighted in `#2563EB`, inactive in `#64748B`.